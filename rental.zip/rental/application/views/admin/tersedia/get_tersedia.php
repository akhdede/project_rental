<?php
foreach($get as $g) {
  $id = $g->id;
}
?>
